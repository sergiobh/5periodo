/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio06.questao01;

/**
 *
 * @author edgardcardoso
 */
public interface SAP {
    public void envia(NotaFiscal nf);
}
