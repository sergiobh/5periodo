/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.ads.imc.estorias.passos;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

/**
 *
 * @author edgardcardoso
 */
public class ImcPasso {
    
    @Given("")
    // Implemente a função do given
    
    @When("")
    // Implemente a função do When
    
    
    @Then("")
    //Implemente a função do Then
    
}
