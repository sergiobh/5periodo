/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.ads.imc;

/**
 *
 * @author edgardcardoso
 */
public enum Situacao {
    
    ABAIXO_DO_PESO,
    PESO_NORMAL,
    ACIMA_DO_PESO,
    OBESIDADE_I,
    OBESIDADE_II,
    OBESIDADE_III
   
    
}
